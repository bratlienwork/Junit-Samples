### jUnit Sample Demo 

This repo includes a sample JUnit project for qTest Automation Host integration demonstration. Refer to below article to learn how to integrate this project with qTest Automation Host.

[Integrate JUnit for Java with Universal Agent (qTest Elite users only)](https://documentation.tricentis.com/qtest/od/en/content/qtest_launch/universal_agent_user_guides/integrate_junit_for_java_with_universal_agent.htm)
